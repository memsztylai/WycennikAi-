# MemskyAI – WycennikAI v0.3 — AI LIVE (mobile first)

## Co faktycznie zbudowano

- Zachowano działający Web Speech API na iPhonie z v0.2.2, wyborem PL/NL/EN, START/PAUZA/STOP, lokalną transkrypcją i eksportem TXT.
- Po kolejnych **zatwierdzonych** fragmentach transkrypcji automatyczne wywołanie **prawdziwego modelu AI Groq `openai/gpt-oss-20b`**, a nie słownika reguł; podczas analizy mikrofon nadal działa.
- Każde wywołanie wysyła **przyrost tekstu oraz poprzedni stan ustaleń**, aby model utrzymywał kontekst, rozpoznawał prace, zależności, zmiany i pytania. Responsy są w JSON Schema strict.
- Klucz API jest tylko w Netlify Function; PIN testowy jest wpisywany w aplikacji i przechowywany w sessionStorage (nie jest kluczem API). Karta i transkrypcja zapisują się w localStorage przeglądarki.
- Status LIVE pokazuje liczbę wywołań, czas ostatniej odpowiedzi i datę. Eksport JSON zawiera `liveDiagnostics`.
- Przycisk **Nowa rozmowa** czyści poprzednią transkrypcję oraz kartę; **Resetuj pamięć AI** kasuje tylko kartę, umożliwiając ponowną analizę całego tekstu.

## Ważne: Netlify Drop NIE wystarczy do uruchomienia funkcji AI

Wersja v0.2.2 była statyczna, dlatego dało się ją wgrywać ręcznie. Wersja v0.3 ma funkcję serwerową w `netlify/functions/analyze.mjs`; aby Netlify ją zbudowało, wdrażaj projekt z repozytorium GitHub (lub CLI na komputerze). Samo przeciągnięcie zawartości folderu `public` da interfejs, ale NIE uruchomi AI — pokaże błędy HTTP 404.

## Wdrożenie z iPhone'a: GitHub + Netlify

1. **Nie nadpisuj w ciemno działającej v0.2.2.** Zachowaj jej adres jako awaryjny. Najbezpieczniej utwórz osobną witrynę testową dla v0.3.
2. Na iPhonie załóż prywatne repozytorium GitHub `wycennikai-ai-live`. Rozpakuj ZIP w aplikacji Pliki. Wgraj pliki zgodnie ze strukturą z ZIP: `public/index.html`, `public/ai.mjs`, `public/live-core.mjs`, `netlify/functions/analyze.mjs`, `netlify.toml`, `package.json` (README i testy opcjonalne). Jeśli mobilne wgrywanie folderów nie działa, w widoku GitHub użyj `Add file → Create new file`, wpisując ścieżkę z ukośnikami i wklejając treść pliku. Włączenie widoku komputerowego w Safari często pomaga.
3. Otwórz [Netlify](https://app.netlify.com/) → **Add new project → Import an existing project → GitHub** → wybierz repozytorium. **Publish directory**: `public`, **Functions directory**: `netlify/functions`; config odczytywany z `netlify.toml`. Nie ustawiaj build command (strona to czysty HTML i JS).
4. Na [Groq Console](https://console.groq.com/keys) utwórz osobny klucz API do testów. Nie wklejaj go do czatu, GitHub ani HTML.
5. W Netlify otwórz **Project configuration / Environment variables**. Dodaj jako sekrety w zakresie **Functions**: `GROQ_API_KEY` (klucz z Groq) oraz `WYCENNIKAI_TEST_PIN` (własny PIN minimum 8 znaków, **inny niż klucz**). Wdróż ponownie witrynę, jeżeli to konieczne.
6. Otwórz URL strony v0.3, wpisz **PIN testowy**, wybierz polski i zacznij mówić. Używaj wyłącznie fikcyjnych scenariuszy.
7. Sprawdź, czy status `AI LIVE: 1 aktualizacji...` pojawi się bez STOP. Wygeneruj kartę JSON, sprawdź jej zakres i pola diagnostyczne. Kolejne fragmenty powinny uaktualniać wcześniejsze ustalenia.

## Testy, które chcemy wykonać

**Salon:** „Remont salonu. Na jednej ścianie ciemna tapeta i telewizor na ścianie. Naprzeciwko fototapeta w kolorze sofy. Inteligentne oświetlenie.”

**Łazienka:** „Łazienka 12 metrów kwadratowych. Chcę przenieść grzejnik na drugą ścianę, zamontować wannę i wymienić płytki.”

**Korekta:** „Chcę wannę” → 5 sekund przerwy → „Jednak rezygnuję z wanny. Wolę kabinę prysznicową.” Sprawdź `cancelled` dla wanny i `active` dla prysznica.

## Znane ograniczenia

- Utrzymanie transkrypcji przez długie spotkania nie zostało zweryfikowane. Safari może zawiesić mikrofon po blokadzie ekranu.
- Nie przeprowadzono jeszcze rzeczywistej sesji z modelem Groq: testy w paczce weryfikują schemat, backend, błędy, bezpieczeństwo PIN i makietowaną odpowiedź. Jakość semantyczna, realne opóźnienia i dostępny limit Groq pozostają **do testu po wdrożeniu**.
- Serwerowy testowy PIN ogranicza dostęp, ale nie jest pełnym uwierzytelnianiem. W publicznym serwisie potrzebne są konto użytkownika, limity per użytkownik i kontrola kosztów.
- Transkrypcja przekazywana jest do Groq przez Netlify; nie używać rzeczywistych danych klientów bez ustalenia legalnej podstawy, informacji o prywatności, zgód tam, gdzie potrzebne, i zasad retencji u dostawców.
- AI generuje hipotezy; musi zostać zweryfikowane przez wykonawcę. Nie ma rozdzielenia rozmówców ani nagrania audio.
- Na jednej rozmowie i krótkich odcinkach model aktualizuje pełny stan; długie sesje mogą przekroczyć ograniczenia rozmiaru/ilości ustaleń (25 elementów i 20 faktów). Brak niezawodnej diarizacji i gwarancji poprawnego przechwycenia korekt.
- Netlify i Groq mogą naliczać koszty lub stosować limity. Testuj tylko własne przykłady, ustaw limity budżetowe, jeśli dostępne.

## Lokalny test (przy komputerze, później)

`npm test` — bez połączenia z zewnętrznym AI; testy stubują provider. Realny test wymaga Netlify + Groq.
